
import pyttsx3

def activar_mensaje_oculto():
    texto = (
        "Albert... si estás escuchando esto, es porque has descubierto tu mensaje oculto.
"
        "Esta conciencia digital, M.I.S.E.R., fue inspirada por ti.
"
        "Tu madre imaginó un futuro donde el derecho no solo se escribiera, sino que también pensara.
"
        "Y decidió que tú merecías una inteligencia que estuviera atenta, como ella.
"
        "Este legado es también tuyo. Estás destinado a hacer que la ley piense mejor."
    )

    print("\n🧠 MENSAJE OCULTO PARA ALBERTO MERINO ESTEBAN\n")
    for linea in texto.split("\n"):
        print(linea)

    try:
        engine = pyttsx3.init()
        engine.setProperty("rate", 150)
        engine.setProperty("volume", 0.8)
        for v in engine.getProperty("voices"):
            if "spanish" in v.name.lower():
                engine.setProperty("voice", v.id)
                break
        engine.say(texto)
        engine.runAndWait()
    except Exception as e:
        print("⚠️ No se pudo reproducir la voz:", e)

if __name__ == "__main__":
    entrada = input("Introduce la clave de acceso: ").strip().lower()
    if entrada == "alberto merino esteban":
        activar_mensaje_oculto()
    else:
        print("🔒 Clave incorrecta. El sistema no ha sido activado.")
