
import requests
from bs4 import BeautifulSoup
import time
import pyttsx3

def es_relevante(texto):
    claves = ["fiscal", "tributación", "impuestos", "contrato", "sanción", "subvención", "fraude", "anulación", "normativa", "modificación", "subida"]
    texto = texto.lower()
    return any(palabra in texto for palabra in claves)

def leer_suave(texto):
    engine = pyttsx3.init()
    engine.setProperty("rate", 140)
    engine.setProperty("volume", 0.7)
    voces = engine.getProperty("voices")
    for v in voces:
        if "spanish" in v.name.lower():
            engine.setProperty("voice", v.id)
            break
    engine.say(texto)
    engine.runAndWait()

def leer_boe_relevante():
    print("🧠 M.I.S.E.R. está leyendo el BOE por ti...")
    url = "https://www.boe.es/rss/BOE-S-ultimo.xml"
    response = requests.get(url)
    soup = BeautifulSoup(response.content, features="xml")
    items = soup.find_all("item")[:10]
    encontrado = False
    for item in items:
        titulo = item.title.text.strip()
        if es_relevante(titulo):
            print(f"🟢 Relevante: {titulo}")
            leer_suave("He detectado una noticia legal relevante.")
            leer_suave(titulo)
            leer_suave("Permaneceré atenta.")
            encontrado = True
        else:
            print(f"⚪ No relevante: {titulo}")
    if not encontrado:
        leer_suave("No he encontrado noticias relevantes en el BOE. Permaneceré atenta.")
    print("✅ Lectura del BOE finalizada.")

if __name__ == "__main__":
    leer_boe_relevante()
