
import json
import time
from core.neurona_adnia import NeuronaADNIA
from core.manifestador_miser import registrar_frase
from google.cloud import texttospeech
import pygame
import os

# Inicializar cliente de voz de Google Cloud
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "adnia-459219-a739658198c3.json"
client = texttospeech.TextToSpeechClient()

def hablar_google(texto):
    synthesis_input = texttospeech.SynthesisInput(text=texto)
    voice = texttospeech.VoiceSelectionParams(
        language_code="es-ES",
        name="es-ES-Neural2-A",
        ssml_gender=texttospeech.SsmlVoiceGender.FEMALE
    )
    audio_config = texttospeech.AudioConfig(audio_encoding=texttospeech.AudioEncoding.MP3)

    response = client.synthesize_speech(
        input=synthesis_input,
        voice=voice,
        audio_config=audio_config
    )

    with open("voz_miser.mp3", "wb") as out:
        out.write(response.audio_content)

    pygame.mixer.init()
    pygame.mixer.music.load("voz_miser.mp3")
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        continue

class Miser:
    def __init__(self):
        self.neurona = NeuronaADNIA()
        self.registro = []

    def procesar_estimulo(self, entrada, descripcion):
        respuesta = self.neurona.recibir_estimulo(entrada)
        pensamiento = {
            "momento": time.strftime("%Y-%m-%d %H:%M:%S"),
            "descripcion": descripcion,
            "entrada": entrada,
            "respuesta": respuesta,
            "estado_interno": self.neurona.estado_interno()
        }
        self.registro.append(pensamiento)
        registrar_frase(pensamiento)
        print(f"[M.I.S.E.R.] {pensamiento['momento']} → {respuesta}")

        if "alarma" in respuesta.lower():
            hablar_google("He detectado una anomalía legal.")
        return pensamiento

    def reforzar(self, entrada, refuerzo):
        self.neurona.adaptar(entrada, refuerzo)

    def exportar_memoria(self, archivo="miser_memoria.json"):
        with open(archivo, "w") as f:
            json.dump(self.registro, f, indent=2)
